# 🐾 BPM — Beast Package Manager

Ein eigener Package Manager wie npm, brew oder apt — gebaut von Beastmeds.

---

## 📦 Installation

```bash
npm install -g beast-package-manager
```

---

## 🚀 Befehle

| Befehl | Beschreibung |
|--------|-------------|
| `bpm install <name>` | Package installieren |
| `bpm install <name> -v 1.2.0` | Bestimmte Version installieren |
| `bpm uninstall <name>` | Package entfernen |
| `bpm upload` | Eigenes Package hochladen |
| `bpm search <query>` | Packages suchen |
| `bpm info <name>` | Package-Details anzeigen |
| `bpm list` | Installierte Packages auflisten |
| `bpm update <name>` | Bestimmtes Package updaten |
| `bpm update` | Alle Packages updaten |

---

## 📤 Eigenes Package veröffentlichen

### Methode 1 — `bpm upload` (manuell)

1. Erstelle eine `bpm.json` in deinem Projekt:

```json
{
  "name": "mein-package",
  "version": "1.0.0",
  "description": "Mein erstes BPM Package",
  "author": "dein-github-username",
  "main": "index.js"
}
```

2. Führe aus:

```bash
bpm upload
```

3. Gib deinen GitHub Token ein (braucht `repo`-Permissions).

---

### Methode 2 — Auto via Git Tag

1. Klone das Registry:

```bash
git clone https://github.com/beastmeds/bpm-registry
```

2. Kopiere den GitHub Actions Workflow `.github/workflows/publish.yml` in dein Repo.

3. Füge den Secret `BPM_REGISTRY_TOKEN` in deinen Repo-Settings hinzu.

4. Erstelle einen Git Tag:

```bash
git tag v1.0.0
git push --tags
```

→ Das Package wird automatisch ins Registry hochgeladen! ✅

---

## 🗂️ Registry

Das Registry läuft auf **GitHub Pages**:
- Website: `https://beastmeds.github.io/bpm-registry`
- JSON API: `https://beastmeds.github.io/bpm-registry/registry.json`

### Registry-Struktur

```
bpm-registry/
├── index.html          ← Website
├── registry.json       ← Package-Datenbank
└── packages/
    └── <name>/
        └── <version>/
            └── index.js
```

---

## 📁 Installationsverzeichnis

Packages werden in `/usr/local/bpm/packages/` installiert.

```
/usr/local/bpm/
├── installed.json      ← Installierte Packages
└── packages/
    └── <name>/
        ├── index.js
        └── bpm.json
```

---

## 🛠️ Entwicklung

```bash
git clone https://github.com/beastmeds/bpm-registry
cd bpm-registry/cli
npm install
node src/index.js install hello-beast
```

---

Made with 🔥 by **Beastmeds**
