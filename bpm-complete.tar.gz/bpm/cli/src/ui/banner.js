import chalk from 'chalk';
import ora from 'ora';

export async function banner() {
  const art = `
${chalk.hex('#FF6B35')('██████╗ ██████╗ ███╗   ███╗')}
${chalk.hex('#FF8C42')('██╔══██╗██╔══██╗████╗ ████║')}
${chalk.hex('#FFA552')('██████╔╝██████╔╝██╔████╔██║')}
${chalk.hex('#FFB347')('██╔══██╗██╔═══╝ ██║╚██╔╝██║')}
${chalk.hex('#FF6B35')('██████╔╝██║     ██║ ╚═╝ ██║')}
${chalk.hex('#FF4500')('╚═════╝ ╚═╝     ╚═╝     ╚═╝')}
`;
  console.log(art);
  console.log(chalk.hex('#FF6B35').bold('  🐾 Beast Package Manager') + chalk.gray(' v1.0.0'));
  console.log(chalk.gray('  ─────────────────────────────\n'));
}

export function spinner(text) {
  return ora({
    text: chalk.cyan(text),
    spinner: {
      interval: 80,
      frames: ['⠋','⠙','⠹','⠸','⠼','⠴','⠦','⠧','⠇','⠏']
    },
    color: 'cyan'
  });
}

export function downloadAnimation(name) {
  const frames = [
    `📦 ${chalk.yellow(name)} ${chalk.gray('░░░░░░░░░░')} 0%`,
    `📦 ${chalk.yellow(name)} ${chalk.hex('#FF6B35')('██')}${chalk.gray('░░░░░░░░')} 20%`,
    `📦 ${chalk.yellow(name)} ${chalk.hex('#FF6B35')('████')}${chalk.gray('░░░░░░')} 40%`,
    `📦 ${chalk.yellow(name)} ${chalk.hex('#FF6B35')('██████')}${chalk.gray('░░░░')} 60%`,
    `📦 ${chalk.yellow(name)} ${chalk.hex('#FF6B35')('████████')}${chalk.gray('░░')} 80%`,
    `📦 ${chalk.yellow(name)} ${chalk.hex('#FF6B35')('██████████')} 100%`,
  ];
  return frames;
}

export function unicodeProgress(current, total, width = 20) {
  const blocks = ['░', '▒', '▓', '█'];
  const filled = Math.floor((current / total) * width);
  const partial = Math.floor(((current / total) * width - filled) * blocks.length);
  const bar =
    chalk.hex('#FF6B35')(blocks[3].repeat(filled)) +
    chalk.hex('#FF8C42')(filled < width ? blocks[partial] || blocks[0] : '') +
    chalk.gray(blocks[0].repeat(Math.max(0, width - filled - 1)));
  const pct = Math.floor((current / total) * 100);
  return `${bar} ${chalk.white.bold(pct + '%')}`;
}

export function success(msg) {
  console.log(chalk.green('  ✔ ') + chalk.white(msg));
}

export function error(msg) {
  console.log(chalk.red('  ✖ ') + chalk.white(msg));
}

export function info(msg) {
  console.log(chalk.cyan('  ℹ ') + chalk.white(msg));
}

export function warn(msg) {
  console.log(chalk.yellow('  ⚠ ') + chalk.white(msg));
}

export async function animateDownload(name, durationMs = 1200) {
  const frames = downloadAnimation(name);
  return new Promise((resolve) => {
    let i = 0;
    const iv = setInterval(() => {
      process.stdout.write(`\r  ${frames[i]}`);
      i++;
      if (i >= frames.length) {
        clearInterval(iv);
        process.stdout.write('\n');
        resolve();
      }
    }, durationMs / frames.length);
  });
}
