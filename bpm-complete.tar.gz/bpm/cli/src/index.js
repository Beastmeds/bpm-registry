#!/usr/bin/env node

import { program } from 'commander';
import { install } from './commands/install.js';
import { uninstall } from './commands/uninstall.js';
import { upload } from './commands/upload.js';
import { search } from './commands/search.js';
import { info } from './commands/info.js';
import { list } from './commands/list.js';
import { update } from './commands/update.js';
import { banner } from './ui/banner.js';

await banner();

program
  .name('bpm')
  .description('🐾 Beast Package Manager')
  .version('1.0.0');

program
  .command('install <name>')
  .alias('i')
  .description('Install a package')
  .option('-v, --version <version>', 'specific version')
  .action(install);

program
  .command('uninstall <name>')
  .alias('un')
  .description('Uninstall a package')
  .action(uninstall);

program
  .command('upload')
  .description('Upload a package to the registry')
  .action(upload);

program
  .command('search <query>')
  .alias('s')
  .description('Search for packages')
  .action(search);

program
  .command('info <name>')
  .description('Show package info')
  .action(info);

program
  .command('list')
  .alias('ls')
  .description('List all installed packages')
  .action(list);

program
  .command('update [name]')
  .alias('up')
  .description('Update a package or all packages')
  .action(update);

program.parse();
