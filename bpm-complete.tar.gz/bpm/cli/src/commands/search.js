import chalk from 'chalk';
import { fetchRegistry, fetchPackage } from '../registry.js';
import { spinner, info as uiInfo, error as uiError } from '../ui/banner.js';
import fs from 'fs';
import path from 'path';

// ── search ──────────────────────────────────────────────────────────────────
export async function search(query) {
  const spin = spinner(`Suche nach "${query}"...`);
  spin.start();
  try {
    const registry = await fetchRegistry();
    spin.stop();
    const q = query.toLowerCase();
    const results = Object.entries(registry.packages).filter(([name, pkg]) =>
      name.toLowerCase().includes(q) ||
      (pkg.versions[pkg.latest]?.description || '').toLowerCase().includes(q)
    );

    if (results.length === 0) {
      console.log(chalk.yellow(`\n  Keine Packages für "${query}" gefunden\n`));
      return;
    }

    console.log(chalk.hex('#FF6B35').bold(`\n  🔍 ${results.length} Ergebnis(se) für "${query}":\n`));
    results.forEach(([name, pkg]) => {
      const latest = pkg.versions[pkg.latest];
      console.log(
        `  ${chalk.yellow.bold(name)} ${chalk.gray('@' + pkg.latest)}\n` +
        `  ${chalk.white(latest?.description || 'Keine Beschreibung')} ${chalk.gray('von')} ${chalk.cyan(latest?.author || '?')}\n`
      );
    });
  } catch (err) {
    spin.fail(chalk.red(err.message));
  }
}

// ── info ─────────────────────────────────────────────────────────────────────
export async function info(name) {
  const spin = spinner(`Info für "${name}"...`);
  spin.start();
  try {
    const pkg = await fetchPackage(name);
    spin.stop();
    const latest = pkg.versions[pkg.latest];
    console.log(chalk.hex('#FF6B35').bold(`\n  📦 ${name}\n`));
    console.log(`  ${chalk.gray('Neueste Version:')}  ${chalk.cyan(pkg.latest)}`);
    console.log(`  ${chalk.gray('Autor:')}            ${chalk.white(latest?.author || '?')}`);
    console.log(`  ${chalk.gray('Beschreibung:')}     ${chalk.white(latest?.description || '-')}`);
    console.log(`  ${chalk.gray('Veröffentlicht:')}   ${chalk.white(latest?.publishedAt ? new Date(latest.publishedAt).toLocaleDateString('de-AT') : '-')}`);
    console.log(chalk.gray(`\n  Alle Versionen: ${Object.keys(pkg.versions).join(', ')}\n`));
  } catch (err) {
    spin.fail(chalk.red(err.message));
  }
}

// ── list ─────────────────────────────────────────────────────────────────────
const DB_PATH = process.platform === 'win32'
  ? path.join(process.env.APPDATA || '', 'bpm', 'installed.json')
  : '/usr/local/bpm/installed.json';

export async function list() {
  let db;
  try { db = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8')); }
  catch { db = { packages: {} }; }

  const pkgs = Object.entries(db.packages);
  if (pkgs.length === 0) {
    console.log(chalk.yellow('\n  Keine Packages installiert\n'));
    return;
  }

  console.log(chalk.hex('#FF6B35').bold(`\n  📋 Installierte Packages (${pkgs.length}):\n`));
  pkgs.forEach(([name, data]) => {
    console.log(
      `  ${chalk.yellow.bold(name)} ${chalk.gray('@' + data.version)}` +
      chalk.gray(`  (installiert: ${new Date(data.installedAt).toLocaleDateString('de-AT')})`)
    );
  });
  console.log();
}

// ── update ────────────────────────────────────────────────────────────────────
export async function update(name) {
  const { install } = await import('./install.js');
  if (name) {
    console.log(chalk.cyan(`\n  Updating ${chalk.yellow.bold(name)}...`));
    await install(name, {});
  } else {
    let db;
    try { db = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8')); }
    catch { db = { packages: {} }; }
    const pkgs = Object.keys(db.packages);
    if (pkgs.length === 0) {
      console.log(chalk.yellow('\n  Keine Packages installiert\n'));
      return;
    }
    console.log(chalk.cyan(`\n  Updating alle ${pkgs.length} Packages...\n`));
    for (const pkg of pkgs) {
      await install(pkg, {});
    }
  }
}
