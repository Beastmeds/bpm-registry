import fs from 'fs';
import path from 'path';
import chalk from 'chalk';
import { spinner, success, error } from '../ui/banner.js';

const INSTALL_DIR = process.platform === 'win32'
  ? path.join(process.env.APPDATA || '', 'bpm', 'packages')
  : '/usr/local/bpm/packages';

const DB_PATH = process.platform === 'win32'
  ? path.join(process.env.APPDATA || '', 'bpm', 'installed.json')
  : '/usr/local/bpm/installed.json';

function loadDB() {
  try { return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8')); }
  catch { return { packages: {} }; }
}
function saveDB(db) {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

export async function uninstall(name) {
  console.log(chalk.red(`\n  Uninstalling ${chalk.yellow.bold(name)}...\n`));

  const db = loadDB();
  if (!db.packages[name]) {
    error(`Package "${chalk.yellow(name)}" ist nicht installiert`);
    return;
  }

  const spin = spinner(`${name} wird entfernt...`);
  spin.start();

  try {
    const pkgDir = path.join(INSTALL_DIR, name);
    if (fs.existsSync(pkgDir)) {
      fs.rmSync(pkgDir, { recursive: true, force: true });
    }
    delete db.packages[name];
    saveDB(db);
    spin.succeed(chalk.green('Erfolgreich entfernt!'));
    console.log();
    success(`${chalk.yellow.bold(name)} wurde deinstalliert\n`);
  } catch (err) {
    spin.fail(chalk.red(err.message));
  }
}
