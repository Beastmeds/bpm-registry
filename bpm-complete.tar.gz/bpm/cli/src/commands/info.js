export { info } from './search.js';
