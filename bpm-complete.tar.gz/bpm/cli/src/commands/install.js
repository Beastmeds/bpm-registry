import fs from 'fs';
import path from 'path';
import chalk from 'chalk';
import { fetchPackageVersion, downloadPackage } from '../registry.js';
import { spinner, animateDownload, success, error, info } from '../ui/banner.js';

const INSTALL_DIR = process.platform === 'win32'
  ? path.join(process.env.APPDATA || '', 'bpm', 'packages')
  : '/usr/local/bpm/packages';

const DB_PATH = process.platform === 'win32'
  ? path.join(process.env.APPDATA || '', 'bpm', 'installed.json')
  : '/usr/local/bpm/installed.json';

function loadDB() {
  try {
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
  } catch {
    return { packages: {} };
  }
}

function saveDB(db) {
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

export async function install(name, opts) {
  console.log(chalk.cyan(`\n  Installing ${chalk.yellow.bold(name)}...\n`));

  const spin = spinner('Registry wird abgefragt...');
  spin.start();

  let pkgData;
  try {
    pkgData = await fetchPackageVersion(name, opts.version);
    spin.succeed(chalk.green('Registry erfolgreich abgefragt'));
  } catch (err) {
    spin.fail(chalk.red(err.message));
    return;
  }

  info(`Version: ${chalk.cyan(pkgData.version)} | Autor: ${chalk.cyan(pkgData.author)}`);
  info(`Größe: ${chalk.cyan(pkgData.size || 'unbekannt')}`);
  console.log();

  // Unicode download animation
  await animateDownload(name, 1400);

  const spin2 = spinner('Package wird installiert...');
  spin2.start();

  try {
    const code = await downloadPackage(pkgData.url);
    const pkgDir = path.join(INSTALL_DIR, name);
    fs.mkdirSync(pkgDir, { recursive: true });
    fs.writeFileSync(path.join(pkgDir, 'index.js'), code);
    fs.writeFileSync(path.join(pkgDir, 'bpm.json'), JSON.stringify({
      name,
      version: pkgData.version,
      author: pkgData.author,
      description: pkgData.description,
      installedAt: new Date().toISOString()
    }, null, 2));

    const db = loadDB();
    db.packages[name] = { version: pkgData.version, installedAt: new Date().toISOString() };
    saveDB(db);

    spin2.succeed(chalk.green('Erfolgreich installiert!'));
    console.log();
    success(`${chalk.yellow.bold(name)}@${chalk.cyan(pkgData.version)} wurde installiert`);
    console.log(chalk.gray(`  → ${path.join(INSTALL_DIR, name)}\n`));
  } catch (err) {
    spin2.fail(chalk.red(err.message));
  }
}
