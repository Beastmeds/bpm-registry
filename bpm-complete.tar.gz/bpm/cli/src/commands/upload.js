import fs from 'fs';
import path from 'path';
import chalk from 'chalk';
import { Octokit } from '@octokit/rest';
import readline from 'readline';
import { spinner, success, error, info, warn } from '../ui/banner.js';

const REGISTRY_REPO = 'bpm-registry';
const REGISTRY_OWNER = 'beastmeds'; // Change this to your GitHub username

function ask(question) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(resolve => rl.question(chalk.cyan(`  ${question} `), ans => { rl.close(); resolve(ans.trim()); }));
}

export async function upload() {
  console.log(chalk.hex('#FF6B35')('\n  📤 Package Upload\n'));

  // Check for bpm.json
  const bpmJsonPath = path.join(process.cwd(), 'bpm.json');
  let meta = {};

  if (fs.existsSync(bpmJsonPath)) {
    meta = JSON.parse(fs.readFileSync(bpmJsonPath, 'utf-8'));
    info(`bpm.json gefunden: ${chalk.yellow(meta.name + '@' + meta.version)}`);
  } else {
    warn('Keine bpm.json gefunden. Bitte Informationen eingeben:\n');
    meta.name = await ask('Package-Name:');
    meta.version = await ask('Version (z.B. 1.0.0):');
    meta.description = await ask('Beschreibung:');
    meta.author = await ask('Autor (GitHub-Username):');
    meta.main = await ask('Entry-File (z.B. index.js):');
  }

  const mainFile = path.join(process.cwd(), meta.main || 'index.js');
  if (!fs.existsSync(mainFile)) {
    error(`Entry-File "${meta.main}" nicht gefunden!`);
    return;
  }

  const githubToken = await ask('GitHub Token (für Registry-Zugriff):');
  if (!githubToken) {
    error('Kein GitHub Token angegeben!');
    return;
  }

  const spin = spinner('Package wird hochgeladen...');
  spin.start();

  try {
    const octokit = new Octokit({ auth: githubToken });
    const code = fs.readFileSync(mainFile, 'utf-8');
    const encoded = Buffer.from(code).toString('base64');

    // Upload package file
    const filePath = `packages/${meta.name}/${meta.version}/index.js`;
    let sha;
    try {
      const existing = await octokit.repos.getContent({
        owner: REGISTRY_OWNER, repo: REGISTRY_REPO, path: filePath
      });
      sha = existing.data.sha;
    } catch {}

    await octokit.repos.createOrUpdateFileContents({
      owner: REGISTRY_OWNER,
      repo: REGISTRY_REPO,
      path: filePath,
      message: `feat: upload ${meta.name}@${meta.version}`,
      content: encoded,
      ...(sha ? { sha } : {})
    });

    // Update registry.json
    let registryData = { packages: {} };
    try {
      const regFile = await octokit.repos.getContent({
        owner: REGISTRY_OWNER, repo: REGISTRY_REPO, path: 'registry.json'
      });
      registryData = JSON.parse(Buffer.from(regFile.data.content, 'base64').toString());
      sha = regFile.data.sha;
    } catch { sha = undefined; }

    if (!registryData.packages[meta.name]) {
      registryData.packages[meta.name] = { versions: {}, latest: meta.version };
    }
    registryData.packages[meta.name].latest = meta.version;
    registryData.packages[meta.name].versions[meta.version] = {
      author: meta.author || 'unknown',
      description: meta.description || '',
      url: `https://raw.githubusercontent.com/${REGISTRY_OWNER}/${REGISTRY_REPO}/main/packages/${meta.name}/${meta.version}/index.js`,
      publishedAt: new Date().toISOString()
    };

    await octokit.repos.createOrUpdateFileContents({
      owner: REGISTRY_OWNER,
      repo: REGISTRY_REPO,
      path: 'registry.json',
      message: `registry: update ${meta.name}@${meta.version}`,
      content: Buffer.from(JSON.stringify(registryData, null, 2)).toString('base64'),
      ...(sha ? { sha } : {})
    });

    spin.succeed(chalk.green('Erfolgreich hochgeladen!'));
    console.log();
    success(`${chalk.yellow.bold(meta.name)}@${chalk.cyan(meta.version)} ist jetzt im Registry`);
    info(`URL: https://beastmeds.github.io/bpm-registry\n`);
  } catch (err) {
    spin.fail(chalk.red('Upload fehlgeschlagen: ' + err.message));
  }
}
