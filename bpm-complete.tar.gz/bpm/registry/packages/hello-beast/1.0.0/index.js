// hello-beast v1.0.0
// Ein Demo-Package für BPM
console.log('🐾 Hello from Beast Package Manager!');
